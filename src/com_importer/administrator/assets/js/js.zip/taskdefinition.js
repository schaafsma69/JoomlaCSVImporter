/*!
 * Task definition object. 
 * Imports task defintion, contains fnuctions for maintenance.
 * Version 1.0
 * 
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 * 
 * Author: Pieter Schaafsma
 */

var importTask = {
	// Properties
	definition: "",
	input: new Array(),
	output: new Array(),
	
	// Methods
	import: function( xmltext ) {
		
	},
	setCSVfields: function( csvtext ) {
		
	},
	addCSVField: function( field ) {
		
	},
	removeCSVField: function( field ) {
		
	},
	setCSVFieldProp: function( field, prop, val) {
		
	},	
	addTable: function( table ) {
		
	},
	addTableField: function( field, prop, val) {
		
	},
	setTableFieldProp: function( field, prop, val) {
		
	},
	removeTableFieldProp: function( field, prop, val) {
		
	}
};

var dbField = {
	db_name:"",
	cvs_name:"",
	type: "int",
	is_primkey:true,
	is_required:true,
	default_val:"NULL"
};

var dbTable = {
	name : "",
	catch_all : false,
	order : 0,
	cond_insert : true,
	use_timestamp : true,
	use_updated: true,
	delete_non_updated : false,
	cleanup_after : true,
	fields : new Array()
}

var cvsField = {
	id: "",
	name: "",
	is_empty_allowed: true,
	format:""
};
